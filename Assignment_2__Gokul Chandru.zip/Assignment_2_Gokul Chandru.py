"""
  Build a python code, Assume u get temperatue and humidity values
  (generated with the random function to a variable) 
  and write a condition to continuosly detect alarm in case of high temeprature)
"""

# Import random function
from random import *    

# Assign random integer values to a variables ranges from 1 to 100
temp = randint(1, 100)

# Assign random integer values to a variables ranges from 1 to 100 
hum = randint(1,100)

# Check the temperature range wheather it exist over 60 (degree celcius)
if (temp > 60):                             
    print("Alert! Temperature is High..!")
    print("Temperature : ",temp)
# Check the humidity range wheather it exist over 60 (normal level is 30-55)
elif (hum > 60):                            
    print("Alert! Humidity is High..!")
    print("Humidity : ",hum)
else:
   print("Temperatue and Humidity level is normal")
